import datetime
import os,sys,stat
import datetime
if len(sys.argv)!=2 :
    print("error")
    sys.exit(0)
st=os.stat(sys.argv[1])
print(st)
date_modification = datetime.datetime.fromtimestamp(st.st_mtime)
print("size :",st.st_size)
print("File :",sys.argv[1])
print("device",st.st_dev)
print("nombre inodes",st.st_ino)
print("doits",st.st_mode)
print("links",st.st_nlink)
print("UID",st.st_uid)

droits = st.st_mode
permissions = oct(droits)[-3:]
permission_proprietaire = "r" if droits & 0o400 else "-"
permission_proprietaire += "w" if droits & 0o200 else "-"
permission_proprietaire += "x" if droits & 0o100 else "-"
permission_groupe = "r" if droits & 0o40 else "-"
permission_groupe += "w" if droits & 0o20 else "-"
permission_groupe += "x" if droits & 0o10 else "-"
permission_autres = "r" if droits & 0o4 else "-"
permission_autres += "w" if droits & 0o2 else "-"
permission_autres += "x" if droits & 0o1 else "-"
permissions_str = permission_proprietaire + permission_groupe + permission_autres
# Afficher les droits d'accès (permissions)
print("({}/{})".format(permissions, permissions_str))

print(date_modification)