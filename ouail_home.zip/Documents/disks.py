import os
import sys
import subprocess

if len(sys.argv) != 4:
    print("Erreur : veuillez entrer exactement trois paramètres.")
    sys.exit(1)

chemin = sys.argv[1]
nb_disques = int(sys.argv[2])
taille_disque = sys.argv[3]

if not os.path.exists(chemin) or not os.access(chemin, os.W_OK):
    print("le chemin n'existe pas ou vous n'avez pas les droits d'écriture.")
    sys.exit(1)

# Calcul de l'espace disque nécessaire
espace_disque = nb_disques * int(taille_disque)

# Vérification de la suffisance de l'espace disque
# os.statvfs(chemin).f_frsize", récupère la taille d'un bloc de fichiers en octets pour le système de fichiers spécifié par le chemin
# os.statvfs(chemin).f_bavail", renvoie le nombre de blocs libres disponibles sur le système de fichiers spécifié par le chemin.
espace_libre = os.statvfs(chemin).f_frsize * os.statvfs(chemin).f_bavail
if espace_libre < espace_disque:
    print("Erreur : espace disque insuffisant.")
    sys.exit(1)

# Vérification de l'existence des fichiers périphériques loop
fichiers_peripheriques = []
for i in range(21,21 + nb_disques):
    fichier = "/dev/loop" + str(i)
    if not os.path.exists(fichier):
        subprocess.call(["sudo", "mknod", fichier, "b", "7", str(i)], stdout=subprocess.PIPE)
    fichiers_peripheriques.append(fichier)

for i in range(1, nb_disques+1):
    nom_disque = "DISK" + str(i)
    chemin_disque = os.path.join(chemin, nom_disque)
    subprocess.call(["dd", "if=/dev/zero", "of="+chemin_disque, "bs="+taille_disque, "count=1"], stdout=subprocess.PIPE)
    subprocess.call(["sudo", "losetup", fichiers_peripheriques[i%21], chemin_disque], stdout=subprocess.PIPE)


