from dataclasses import dataclass,field
@dataclass
class User:
    name:str
    passwd:str